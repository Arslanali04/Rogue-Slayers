﻿using UnityEngine;
using MarsFPSKit.UI;
using Xsolla.Login;
using TMPro;
using Xsolla.Core;
using System.Linq;
using Xsolla.Store;
using Debug = UnityEngine.Debug;
using UnityEngine.UI;
using Xsolla.Core.Browser;
using System;
using System.Collections;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaLogin : Kit_MenuLoginBase
        {
            /// <summary>
            /// The loadout submenus
            /// </summary>
            [Header("Menu")]
            public UI.MenuScreen[] menuScreens;
            /// <summary>
            /// Value at which the concat started
            /// </summary>
            public int concatStart;
            /// <summary>
            /// Assigned in initialize
            /// </summary>
            private Kit_MenuManager menuManager;

            /// <summary>
            /// Local login screen
            /// </summary>
            [Header("Login")]
            public int loginScreenLocal;
            /// <summary>
            /// Username for logging in
            /// </summary>
            public TMP_InputField loginUsername;
            /// <summary>
            /// Password for logging in
            /// </summary>
            public TMP_InputField loginPassword;
            /// <summary>
            /// Social logins
            /// </summary>
            public Kit_XsollaLoginSocialButton[] loginSocials;
            /// <summary>
            /// If set to true, it will create a logout button
            /// </summary>
            public bool loginEnableLogout = true;

            /// <summary>
            /// Screen for registration
            /// </summary>
            [Header("Register")]
            public int registerScreenLocal = 2;
            /// <summary>
            /// Username for registration
            /// </summary>
            public TMP_InputField registerUsername;
            /// <summary>
            /// Email for registration
            /// </summary>
            public TMP_InputField registerEmail;
            /// <summary>
            /// Password for registration
            /// </summary>
            public TMP_InputField registerPassword;

            /// <summary>
            /// Username to recover
            /// </summary>
            [Header("Recover")]
            public TMP_InputField recoverUsername;

            [Tooltip("Screen that is displayed when the reigster is done")]
            [Header("Result Pages")]
            /// <summary>
            /// Screen that is displayed when the reigster is done
            /// </summary>
            public int registerSuccessScreenId;
            [Tooltip("Text to display the email")]
            /// <summary>
            /// Text to display the email
            /// </summary>
            public TextMeshProUGUI registerSuccessTextEmail;
            [Tooltip("Screen that is displayed when the register goes wrong")]
            /// <summary>
            /// Screen that is displayed when the register goes wrong
            /// </summary>
            public int registerFailureScreenId;
            [Tooltip("Displays the register failure text")]
            /// <summary>
            /// Displays the register failure text
            /// </summary>
            public TextMeshProUGUI registerFailureText;
            [Tooltip("Screen that is displayed when the change password goes smoothly")]
            /// <summary>
            /// Screen that is displayed when the change password goes smoothly
            /// </summary>
            public int changePasswordSuccessScreenId;
            [Tooltip("Screen id for change password failure")]
            /// <summary>
            /// Screen id for change password failure
            /// </summary>
            public int changePasswordFailureScreenId;
            [Tooltip("Text that displays the error")]
            /// <summary>
            /// Text that displays the error
            /// </summary>
            public TextMeshProUGUI changePasswordFailureText;
            [Tooltip("Screen that is displayed when the login goes wrong")]
            /// <summary>
            /// Screen that is displayed when the login goes wrong
            /// </summary>
            public int loginErrorScreenId;
            /// <summary>
            /// Displays the login error
            /// </summary>
            public TextMeshProUGUI loginErrorText;

            [Tooltip("If we are waiting for an action, this is on")]
            /// <summary>
            /// If we are waiting for an action, this is on
            /// </summary>
            [Header("Waiting Animation")]
            public GameObject waitingAnimationOverlay;

            #region Runtime Values
            /// <summary>
            /// Were we successfully authenticated?
            /// </summary>
            public static bool wasAuthenticated;
            /// <summary>
            /// The username that we submitted
            /// </summary>
            public static string submittedUsername;
            #endregion

            #region Unity Calls
            private void Awake()
            {
                if (menuScreens.Length > 0)
                {
                    Kit_MenuManager manager = FindObjectOfType<Kit_MenuManager>();

                    if (manager)
                    {
                        concatStart = manager.menuScreens.Length;
                        //Merge the lists
                        manager.menuScreens = manager.menuScreens.Concat(menuScreens).ToArray();
                        //Set our screen
                        loginScreen = concatStart + loginScreenLocal;
                    }
                }

                //Disable all the roots
                for (int i = 0; i < menuScreens.Length; i++)
                {
                    if (menuScreens[i].root)
                    {
                        //Disable
                        menuScreens[i].root.SetActive(false);
                    }
                    else
                    {
                        Debug.LogError("Menu root at index " + i + " is not assigned.", this);
                    }
                }

                //Setup social logins
                for (int i = 0; i < loginSocials.Length; i++)
                {
                    int id = i;
                    loginSocials[id].btn.onClick.AddListener(delegate { SocialLogin(loginSocials[id].socialProvider); });
                }

                //Setup logout
                if (loginEnableLogout)
                {
                    Kit_MenuMainScreen mainScreen = FindObjectOfType<Kit_MenuMainScreen>();

                    if (mainScreen)
                    {
                        //Duplicate the multiplayer button
                        GameObject logoutButton = Instantiate(mainScreen.multiplayerButton.gameObject, mainScreen.multiplayerButton.transform.parent);
                        Button btn = logoutButton.GetComponent<Button>();
                        TextMeshProUGUI txt = logoutButton.GetComponentInChildren<TextMeshProUGUI>();
                        if (txt)
                        {
                            //Set logout text
                            txt.text = "Logout";
                        }
                        //Set before exit
                        logoutButton.transform.SetSiblingIndex(logoutButton.transform.parent.childCount - 2);
                        //What the button does
                        btn.onClick.RemoveAllListeners();
                        btn.onClick.AddListener(delegate { Logout(); });
                    }
                }
            }
            #endregion

            #region Menu Calls
            /// <summary>
            /// Call for buttons
            /// </summary>
            /// <param name="newMenu"></param>
            public void ChangeMenuButton(int newMenu)
            {
                menuManager.ChangeMenuButton(concatStart + newMenu);
            }
            #endregion

            #region Social Auth
            private SocialProvider socialCurrentProvider;
            private string socialCurrentToken;

            public void SocialLogin(SocialProvider sp)
            {
                socialCurrentProvider = sp;
                /*
                BrowserHelper.Instance.Open(XsollaLogin.Instance.GetSocialNetworkAuthUrl(sp), true);
                SinglePageBrowser2D browser = BrowserHelper.Instance.GetLastBrowser();
                browser.GetComponent<XsollaBrowser>().Navigate.UrlChangedEvent += ;
                */
                var browser = BrowserHelper.Instance.InAppBrowser;
                browser.Open(XsollaLogin.Instance.GetSocialNetworkAuthUrl(sp));
                browser.AddUrlChangeHandler(SocialUrlChanged);
            }

            public void SocialUrlChanged(string newUrl)
            {
                if (XsollaSettings.AuthorizationType == AuthorizationType.JWT && ParseUtils.TryGetValueFromUrl(newUrl, ParseParameter.token, out var token))
                {
                    Debug.Log($"We take{Environment.NewLine}from URL:{newUrl}{Environment.NewLine}token = {token}");
                    StartCoroutine(SuccessAuthCoroutine(token));
                }
                else if (XsollaSettings.AuthorizationType == AuthorizationType.OAuth2_0 && ParseUtils.TryGetValueFromUrl(newUrl, ParseParameter.code, out var code))
                {
                    Debug.Log($"We take{Environment.NewLine}from URL:{newUrl}{Environment.NewLine}code = {code}");
                    XsollaLogin.Instance.ExchangeCodeToToken(code, OnSocialSuccess, OnSocialError);
                }
            }

            private void OnSocialSuccess(string socialToken)
            {
                Debug.Log($"[Xsolla] Social authorization successful. Token: {socialToken}");
                StartCoroutine(SuccessAuthCoroutine(socialToken));
            }

            private void OnSocialError(Error error)
            {
                Debug.Log($"[Xsolla] Social authorization failed. Description: {error.errorMessage}");
            }

            private IEnumerator SuccessAuthCoroutine(string token)
            {
                waitingAnimationOverlay.SetActive(true);
                socialCurrentToken = token;
                yield return new WaitForEndOfFrame();
#if UNITY_EDITOR || UNITY_STANDALONE
                Destroy(BrowserHelper.Instance.gameObject);
#endif
                OnSocialTokenSuccess(token);
            }

            public void OnSocialTokenSuccess(string token)
            {
                GetUserInfo(token, OnUserInfoSuccess, OnUserInfoError);
            }

            private void OnUserInfoSuccess(UserInfo obj)
            {
                CompleteSuccessfulAuth(socialCurrentToken, obj.username);
            }

            private void OnUserInfoError(Error error)
            {
                Debug.Log($"[Xsolla] User Info Error. Description: {error.errorMessage}");
                waitingAnimationOverlay.SetActive(false);
            }

            private void CompleteSuccessfulAuth(string token, string userName, bool isBasicAuth = false, bool isPaystation = false, bool isSaveToken = false)
            {
                if (isSaveToken)
                    XsollaLogin.Instance.SaveToken(Constants.LAST_SUCCESS_AUTH_TOKEN, token);

                if (!isBasicAuth)
                {
                    token = token.Split('&').First();
                    Token.Instance = Token.Create(token);
                }

                Debug.Log($"[Xsolla] Successful auth with token = {token}");

                waitingAnimationOverlay.SetActive(false);

                wasAuthenticated = true;
                //Set name
                Kit_GameSettings.userName = userName;
                //Proceed
                menuManager.LoggedIn(userName);
            }

            public void GetUserInfo(string token, Action<UserInfo> onSuccess, Action<Error> onError = null)
            {
                XsollaLogin.Instance.GetUserInfo(token, info =>
                {
                    onSuccess?.Invoke(info);
                }, onError);
            }
            #endregion

            public override void Initialize(Kit_MenuManager mm)
            {
                //Token callback
                Token.TokenChanged += OnXsollaTokenChanged;
                //Cache
                menuManager = mm;
                //Set Ref
                WebRequestHelper.Instance.SetReferralAnalytics("mmfpse-xsolla-weapon-store-addon", Kit_XsollaSettings.version);
                if (wasAuthenticated)
                {
                    //Set name
                    Kit_GameSettings.userName = submittedUsername;
                    //Proceed
                    menuManager.LoggedIn(submittedUsername);
                }
                else
                {
                    //Switch to our menu
                    mm.SwitchMenu(loginScreen);
                }
            }

            private void OnXsollaTokenChanged()
            {
                Debug.Log("[XSolla] Login Token changed");
            }

            #region Login
            public void Login()
            {
                //Check if username is not empty, password is not empty
                if (!loginUsername.text.IsNullOrWhiteSpace() && !loginPassword.text.IsNullOrWhiteSpace())
                {
                    //Cache name
                    submittedUsername = loginUsername.text;
                    //Call Xsolla
                    XsollaLogin.Instance.SignIn(loginUsername.text, loginPassword.text, false, null, OnLoginSuccess, OnLoginError);
                    //Enable
                    waitingAnimationOverlay.SetActive(true);
                }
                else
                {
                    if (loginUsername.text.IsNullOrWhiteSpace())
                    {
                        loginErrorText.text = "Enter your username!";
                    }
                    else if (loginPassword.text.IsNullOrWhiteSpace())
                    {
                        loginErrorText.text = "Enter your password!";
                    }
                    ChangeMenuButton(loginErrorScreenId);
                }
            }


            private void OnLoginError(Error obj)
            {
                //Set text
                loginErrorText.text = obj.errorMessage;

                ChangeMenuButton(loginErrorScreenId);

                //Disable wait
                waitingAnimationOverlay.SetActive(false);
            }

            private void OnLoginSuccess(string obj)
            {
                //Store
                wasAuthenticated = true;
                //Set name
                Kit_GameSettings.userName = submittedUsername;
                //Proceed
                menuManager.LoggedIn(submittedUsername);
                //Disable wait
                waitingAnimationOverlay.SetActive(false);
            }

            public void Logout()
            {
                //Check if xsolla is doing anything
                if (!WebRequestHelper.Instance.IsBusy())
                {
                    //Store
                    wasAuthenticated = false;
                    //Set name
                    Kit_GameSettings.userName = "Unassigned";
                    submittedUsername = "";
                    menuManager.LoggedOut();
                    //Proceed (go back)
                    menuManager.SwitchMenu(concatStart + loginScreenLocal, true);
                    //Disable wait
                    waitingAnimationOverlay.SetActive(false);
                    //Remove Token
                    //XsollaStore.Instance.Token = null;
                    //Reset username and password
                    loginUsername.text = "";
                    loginPassword.text = "";
                }
            }
            #endregion

            #region Register
            public void Register()
            {
                //Check if username is not empty, password is not empty and password is longer than 6 values
                if (!registerUsername.text.IsNullOrWhiteSpace() && !registerEmail.text.IsNullOrWhiteSpace() && !registerPassword.text.IsNullOrWhiteSpace() && registerPassword.text.Length >= 6)
                {
                    //Set email text
                    registerSuccessTextEmail.text = "Your account was successfully created. \n Please check " + registerEmail.text + " to confirm your email!";

                    //Submit
                    XsollaLogin.Instance.Registration(registerUsername.text, registerPassword.text, registerEmail.text, null, null, true, true, null,OnRegisterSuccess, OnRegisterError);

                    //Enable
                    waitingAnimationOverlay.SetActive(true);
                }
                else
                {
                    if (registerUsername.text.IsNullOrWhiteSpace())
                    {
                        registerFailureText.text = "Name cannot be null";
                    }
                    else if (registerEmail.text.IsNullOrWhiteSpace())
                    {
                        registerFailureText.text = "E-Mail cannot be null";
                    }
                    else if (registerPassword.text.IsNullOrWhiteSpace())
                    {
                        registerFailureText.text = "Password cannot be null";
                    }
                    else if (registerPassword.text.Length < 6)
                    {
                        registerFailureText.text = "Password needs to  have at least 6 characters";
                    }

                    ChangeMenuButton(registerFailureScreenId);
                }
            }

            private void OnRegisterError(Error obj)
            {
                //Set text
                registerFailureText.text = obj.errorMessage;

                ChangeMenuButton(registerFailureScreenId);
                //Disable wait
                waitingAnimationOverlay.SetActive(false);
            }

            private void OnRegisterSuccess()
            {
                ChangeMenuButton(registerSuccessScreenId);
                //Disable wait
                waitingAnimationOverlay.SetActive(false);
            }
            #endregion

            #region Change Password
            public void ChangePassword()
            {
                if (!recoverUsername.text.IsNullOrWhiteSpace())
                {
                    XsollaLogin.Instance.ResetPassword(recoverUsername.text, OnRecoverSuccess, OnRecoverFailure);
                    //Display animation
                    waitingAnimationOverlay.SetActive(true);
                }
                else
                {
                    //Set failure
                    changePasswordFailureText.text = "Enter your username!";
                    //Display it
                    ChangeMenuButton(changePasswordFailureScreenId);
                }
            }

            private void OnRecoverFailure(Error obj)
            {
                //Display what went wrong
                changePasswordFailureText.text = obj.errorMessage;
                //Display menu
                ChangeMenuButton(changePasswordFailureScreenId);
                //Hide animation
                waitingAnimationOverlay.SetActive(false);
            }

            private void OnRecoverSuccess()
            {
                //Display menu
                ChangeMenuButton(changePasswordSuccessScreenId);
                //Hide animation
                waitingAnimationOverlay.SetActive(false);
            }
            #endregion
        }
    }
}
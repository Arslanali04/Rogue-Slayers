﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Xsolla.Core;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaPlayerModelPreview : MonoBehaviour
        {
            /// <summary>
            /// Weapon preview
            /// </summary>
            public Image img;
            /// <summary>
            /// Text to display name
            /// </summary>
            public TextMeshProUGUI txt;
            /// <summary>
            /// XSolla image url
            /// </summary>
            public string imageUrl;

            public void UpdateImage()
            {
                if (!string.IsNullOrEmpty(imageUrl))
                    ImageLoader.Instance.GetImageAsync(imageUrl, (_, sprite) =>
                    {
                        if (img)
                            img.sprite = sprite;
                    });
                else
                    Debug.LogError("Player Model has no image url.");
            }
        }
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;
using Xsolla.Core;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        /// <summary>
        /// This script is almost a direct copy of this one without a license
        /// https://gitlab.com/jonnohopkins/tmp-hyperlinks/-/blob/master/Assets/OpenHyperlinks.cs
        /// slight modifications have been made
        /// </summary>
        [RequireComponent(typeof(TextMeshProUGUI))]
        public class Kit_XsollaPrivacyPolicy : MonoBehaviour, IPointerClickHandler
        {
            public bool doesColorChangeOnHover = true;
            public Color hoverColor = new Color(60f / 255f, 120f / 255f, 1f);

            /// <summary>
            /// Stored text
            /// </summary>
            private TextMeshProUGUI txt;
            /// <summary>
            /// Canvas this text is part of
            /// </summary>
            private Canvas myCanvas;
            /// <summary>
            /// If the canvas is a non screen overlay canvas, this is the camera it belongs to
            /// </summary>
            private Camera myCamera;

            public bool isLinkHighlighted { get { return pCurrentLink != -1; } }

            private int pCurrentLink = -1;
            private List<Color32[]> pOriginalVertexColors = new List<Color32[]>();

            protected virtual void Awake()
            {
                txt = GetComponent<TextMeshProUGUI>();
                myCanvas = GetComponentInParent<Canvas>();

                // Get a reference to the camera if Canvas Render Mode is not ScreenSpace Overlay.
                if (myCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
                    myCamera = null;
                else
                    myCamera = myCanvas.worldCamera;
            }

            void LateUpdate()
            {
                //Is the cursor in the correct region (above the text area) and furthermore, in the link region?
                bool isHoveringOver = TMP_TextUtilities.IsIntersectingRectTransform(txt.rectTransform, Input.mousePosition, myCamera);
                int linkIndex = isHoveringOver ? TMP_TextUtilities.FindIntersectingLink(txt, Input.mousePosition, myCamera)
                    : -1;

                //Clear previous link selection if one existed.
                if (pCurrentLink != -1 && linkIndex != pCurrentLink)
                {
                    SetLinkToColor(pCurrentLink, (linkIdx, vertIdx) => pOriginalVertexColors[linkIdx][vertIdx]);
                    pOriginalVertexColors.Clear();
                    pCurrentLink = -1;
                }

                //Handle new link selection.
                if (linkIndex != -1 && linkIndex != pCurrentLink)
                {
                    pCurrentLink = linkIndex;
                    if (doesColorChangeOnHover)
                        pOriginalVertexColors = SetLinkToColor(linkIndex, (_linkIdx, _vertIdx) => hoverColor);
                }
            }

            public void OnPointerClick(PointerEventData eventData)
            {
                int linkIndex = TMP_TextUtilities.FindIntersectingLink(txt, Input.mousePosition, myCamera);
                if (linkIndex != -1)
                { 
                    //Was a link clicked?
                    TMP_LinkInfo linkInfo = txt.textInfo.linkInfo[linkIndex];
                    //Open the link id as a url, which is the metadata we added in the text field
                    BrowserHelper.Instance.Open(linkInfo.GetLinkID(), true);
                }
            }

            List<Color32[]> SetLinkToColor(int linkIndex, Func<int, int, Color32> colorForLinkAndVert)
            {
                TMP_LinkInfo linkInfo = txt.textInfo.linkInfo[linkIndex];

                List<Color32[]> oldVertColors = new List<Color32[]>(); // store the old character colors

                for (int i = 0; i < linkInfo.linkTextLength; i++)
                { // for each character in the link string
                    int characterIndex = linkInfo.linkTextfirstCharacterIndex + i; // the character index into the entire text
                    var charInfo = txt.textInfo.characterInfo[characterIndex];
                    int meshIndex = charInfo.materialReferenceIndex; // Get the index of the material / sub text object used by this character.
                    int vertexIndex = charInfo.vertexIndex; // Get the index of the first vertex of this character.

                    Color32[] vertexColors = txt.textInfo.meshInfo[meshIndex].colors32; // the colors for this character
                    oldVertColors.Add(vertexColors.ToArray());

                    if (charInfo.isVisible)
                    {
                        vertexColors[vertexIndex + 0] = colorForLinkAndVert(i, vertexIndex + 0);
                        vertexColors[vertexIndex + 1] = colorForLinkAndVert(i, vertexIndex + 1);
                        vertexColors[vertexIndex + 2] = colorForLinkAndVert(i, vertexIndex + 2);
                        vertexColors[vertexIndex + 3] = colorForLinkAndVert(i, vertexIndex + 3);
                    }
                }

                // Update Geometry
                txt.UpdateVertexData(TMP_VertexDataUpdateFlags.All);

                return oldVertColors;
            }
        }
    }
}

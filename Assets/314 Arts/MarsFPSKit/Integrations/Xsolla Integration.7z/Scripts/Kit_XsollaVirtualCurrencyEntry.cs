﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Xsolla.Core;
using Debug = UnityEngine.Debug;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaVirtualCurrencyEntry : MonoBehaviour
        {
            /// <summary>
            /// This displays our virtualCurrency's name
            /// </summary>
            public TextMeshProUGUI virtualCurrencyName;
            /// <summary>
            /// Image that displays our virtualCurrency
            /// </summary>
            public Image virtualCurrencyImage;
            /// <summary>
            /// Price
            /// </summary>
            public TextMeshProUGUI price;
            /// <summary>
            /// If the price we selected is discounted, this will show the previous price
            /// </summary>
            public TextMeshProUGUI priceNonDiscounted;
            /// <summary>
            /// Button used for buying a virtualCurrency
            /// </summary>
            public Button buyButton;
            /// <summary>
            /// XSolla image url
            /// </summary>
            public string imageUrl;

            private void Start()
            {
                if (!string.IsNullOrEmpty(imageUrl))
                    ImageLoader.Instance.GetImageAsync(imageUrl, (_, sprite) =>
                    {
                        if (virtualCurrencyImage)
                            virtualCurrencyImage.sprite = sprite;
                    });
                else
                    Debug.LogError("Virtual Currency Package has no image url.");
            }
        }
    }
}
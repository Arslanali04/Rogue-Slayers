﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        public class Kit_XsollaWeaponPreview : MonoBehaviour
        {
            /// <summary>
            /// Weapon preview
            /// </summary>
            public Image img;
            /// <summary>
            /// Text to display name
            /// </summary>
            public TextMeshProUGUI txt;
        }
    }
}
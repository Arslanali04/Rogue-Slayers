﻿using UnityEngine;

namespace MarsFPSKit
{
    namespace Xsolla
    {
        [System.Serializable]
        public class StringToIntDictionary : SerializableDictionary<string, int> { }

        [System.Serializable]
        public class XsollaTeamSettings
        {
            [Tooltip("Team name, for organization purposes. Not actually used in game.")]
            /// <summary>
            /// Team name, for organization purposes. Not actually used in game (the name is defined by the team in <see cref="Kit_GameInformation.allPvpTeams"/> files
            /// </summary>
            public string teamName;
            [Tooltip("Our default skin that is always available")]
            /// <summary>
            /// Our default skin that is always available
            /// </summary>
            public string startingSkin;
            [Tooltip("This maps xsolls skus to ingame ids")]
            /// <summary>
            /// This maps xsolls skus to ingame ids
            /// </summary>
            public StringToIntDictionary storePlayerModelIdToIngamePlayerModelId;
        }

        [CreateAssetMenu(menuName = "MarsFPSKit/Addons/Xsolla Weapon Store/New Settings File")]
        public class Kit_XsollaSettings : ScriptableObject
        {
            public static readonly string version = "1.0.0.0";

            /// <summary>
            /// This maps weapon IDs from the Xsolla store config to ingame weapon IDs
            /// </summary>
            [Tooltip("This maps weapon IDs from the Xsolla store config to ingame weapon IDs")]
            [Header("Store Settings")]
            public StringToIntDictionary storeWeaponIdToIngameWeaponId;
            [Tooltip("Our starting gear, one for each slot")]
            /// <summary>
            /// Our starting gear, one for each slot
            /// </summary>
            public string[] starterGear;
            /// <summary>
            /// Settings for player models
            /// </summary>
            public XsollaTeamSettings[] teamSettings;

            /// <summary>
            /// How many loadouts the player can have
            /// </summary>
            [Header("Loadout Settings")]
            public int loadoutAmount = 5;
        }
    }
}